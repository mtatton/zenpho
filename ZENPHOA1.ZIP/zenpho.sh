#!/bin/bash
#
# (c) 2018 Shinobi from Infoline
#
BBS_PATH=/u01/bbs
python $BBS_PATH/scripts/zenpho.py
