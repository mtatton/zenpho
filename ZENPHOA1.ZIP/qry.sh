#!/bin/bash
#
# (c) 2018 Shinobi from Infoline
#
BBS_PATH=/u01/bbs
sqlite3 $BBS_PATH/data/zenpho.db
